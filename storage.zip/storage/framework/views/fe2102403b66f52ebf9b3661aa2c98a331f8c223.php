

<?php $__env->startSection('adminlte-plugins-css'); ?>
    <!-- Bootstrap4 Duallistbox -->
    <link rel="stylesheet" href="<?php echo e(asset('/plugins/bootstrap4-duallistbox/bootstrap-duallistbox.min.css')); ?>">
    <!-- daterange picker -->
    <link rel="stylesheet" href="<?php echo e(asset('/plugins/daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('template_title'); ?>
    Performance Comercial
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="card card-primary card-outline card-tabs">
                <div class="card-header p-0 pt-1 border-bottom-0">
                    <ul class="nav nav-tabs" id="custom-tabs-three-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="custom-tabs-three-home-tab" data-toggle="pill"
                                href="#custom-tabs-three-home" role="tab" aria-controls="custom-tabs-three-home"
                                aria-selected="true">Por Consultor</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="custom-tabs-three-profile-tab" data-toggle="pill"
                                href="#custom-tabs-three-profile" role="tab" aria-controls="custom-tabs-three-profile"
                                aria-selected="false">Por cliente</a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content" id="custom-tabs-three-tabContent">
                        <div class="tab-pane fade show active" id="custom-tabs-three-home" role="tabpanel"
                            aria-labelledby="custom-tabs-three-home-tab">
                            <div class="card card-default">

                                <!-- /.card-header -->
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-10">
                                            <div class="form-group">
                                                <label>Período de tiempo:</label>

                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text">
                                                            <i class="far fa-calendar-alt"></i>
                                                        </span>
                                                    </div>
                                                    <input type="text" class="form-control float-right" id="reservation">
                                                </div>
                                                <!-- /.input group -->
                                            </div>
                                            <div class="form-group">
                                                <label>Consultores</label>
                                                <select class="duallistbox" multiple="multiple">
                                                    <?php $__currentLoopData = $consultores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option><?php echo e($consultor->no_usuario); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="card" style="top: 30px;">
                                                <div class="card-header">
                                                    <h3 class="card-title" style="word-break: break-word;">Acciones</h3>
                                                </div>
                                                <div class="card-body row">
                                                    <button type="button" class="btn btn-primary btn-block"
                                                        onclick="relatorico()"><i class="fas fa-calculator fa-fw"></i>
                                                        Relatórico</button>
                                                    <button type="button" class="btn btn-info btn-block btn-flat"><i
                                                            class="fa fa-bell"></i>Gráfico</button>
                                                    <button type="button" class="btn btn-danger btn-block btn-sm"><i
                                                            class="fa fa-bell"></i>Pizza</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-12">

                                        <!-- /.form-group -->
                                    </div>
                                    <!-- /.col -->
                                </div>
                                <!-- /.row -->
                            </div>
                        </div>
                        <div class="tab-pane fade" id="custom-tabs-three-profile" role="tabpanel"
                            aria-labelledby="custom-tabs-three-profile-tab">
                        </div>
                    </div>
                </div>
                <!-- /.card -->
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('adminlte-plugins'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(asset('/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('/dist/js/adminlte.min.js')); ?>"></script>


    <!-- Bootstrap4 Duallistbox -->
    <script src="<?php echo e(asset('/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js')); ?>"></script>
    <!-- InputMask -->
    <script src="<?php echo e(asset('/plugins/moment/moment.min.js')); ?>"></script>
    <!-- date-range-picker -->
    <script src="<?php echo e(asset('/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
    <script>
        $(function() {
            $('.duallistbox').bootstrapDualListbox();
            //Date range picker
            $('#reservation').daterangepicker();
        })
    </script>
    <script>
        $_token = "<?php echo e(csrf_token()); ?>";

        function relatorico() {
            alert("relatorico");
            $.ajax({
                headers: {
                    'X-CSRF-Token': $('meta[name=_token]').attr('content')
                },
                url: "<?php echo e(route('performancecomercial.relatorico')); ?>",
                type: "GET",
                cache: false,
                data: {
                    '_token': $_token
                },
                datatype: 'html',
                success: function(data) {
                    console.log(data);
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\agencetest\resources\views/performancecomercial/index.blade.php ENDPATH**/ ?>